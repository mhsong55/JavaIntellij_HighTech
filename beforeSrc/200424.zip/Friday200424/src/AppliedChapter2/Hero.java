package AppliedChapter2;

public class Hero {
    String name;
    int hp;

    // 기본 생성자 (Constructor)
    public Hero() {}
}
