package Chapter13;

public interface X {
    void a();
}
