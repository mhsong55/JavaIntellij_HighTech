package Chapter13;

public class B extends Y {
    @Override
    public void a() {
        System.out.println("Ba");
    }
    @Override
    public void b() {
        System.out.println("Bb");
    }
    public void c() {
        System.out.println("Bc");
    }
}
