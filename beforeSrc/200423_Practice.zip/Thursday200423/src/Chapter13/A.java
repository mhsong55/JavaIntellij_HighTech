package Chapter13;

public class A extends Y {
    @Override
    public void a() {
        System.out.println("Aa");
    }
    @Override
    public void b() {
        System.out.println("Ab");
    }
    public void c() {
        System.out.println("Ac");
    }
}
