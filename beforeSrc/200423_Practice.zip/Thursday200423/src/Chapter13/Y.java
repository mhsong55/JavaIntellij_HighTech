package Chapter13;

public abstract class Y implements X {
    public abstract void a();
    public abstract void b();
}
